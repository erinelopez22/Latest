﻿using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Threading.Tasks;
using System.Web;
using System.IO;
using System.Net.Http.Headers;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Data;
using Snapshot_API.DAL;
using Snapshot_API.Models;
using System.Collections.Generic;
using Microsoft.Owin;


namespace Snapshot_API.Controllers
{
    [RoutePrefix("api/snapshot")]
    public class SnapshotController : ApiController
    {

        [Route("post")]
        [HttpPost]
        public string post([FromBody] List<object> SnapDet)
        {
            string Results = "";
            try
            {
                //DAL.dal_Snapshot.readXLS(Results);
                //DAL.dal_Snapshot.readXLSInterop(Results);
                return Results;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpGet]
        [Route("get")]
        public string Get(string whcode)
        {

            string result = "";
            try
            {
                result = DAL.dal_Snapshot.GetSSperBranch(whcode);
                return result;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }

        [HttpGet]
        [Route("getAllbranch")]
        public DataTable Get()
        {
            try
            {
                DataTable dt = DAL.dal_Snapshot.GetSSAllBranch();
                return dt;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpGet]
        [Route("Dashboard")]
        public DashModel Dashboard(int Yr)
        {
            try
            {
                DashModel dm = new Models.DashModel();

                DataTable dt = DAL.dal_Snapshot.getDash(Yr);
                DataTable dt2 = DAL.dal_Snapshot.getDash2(Yr);
                dm.dash1 = dt;
                dm.dash2 = dt2;

                return dm;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpPost]
        [Route("importFile")]
        public IHttpActionResult importFile()
        {

            try
            {
                
                if (System.Web.HttpContext.Current.Request.Files.Count > 0)
                {
                    var file = System.Web.HttpContext.Current.Request.Files[0];
                    HttpPostedFile Filenam = file;
                    HttpFileCollection uploads = HttpContext.Current.Request.Files;
                    string path = System.Web.HttpContext.Current.Server.MapPath("~/Uploads/");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    string sav = Path.Combine(path, Filenam.FileName);
                    file.SaveAs(sav);
                    
                }
                
                

                //DataTable dt = DAL.dal_Snapshot.GetSSAllBranch();
                var rep = new object();
                
                return Ok(rep);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpPost]
        [Route("import")]
        public string Import(string Brnch, string FileName)
        {
            string result = "";
            try
            {
                string pathRet = System.Web.HttpContext.Current.Server.MapPath("~/Uploads/" + FileName);
                    try
                    {
                        DAL.dal_Snapshot.readXLSInterop(Brnch, pathRet);
                        //DAL.dal_Snapshot.createExcel();
                    }
                    catch (Exception ex)
                    {
                        var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                        {
                            Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                            StatusCode = HttpStatusCode.InternalServerError,
                            ReasonPhrase = ex.Message
                        };
                        throw new HttpResponseException(response);
                        return ex.Message.ToString();
                    }

                    
                    return "Success";
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }

        [HttpPost]
        [Route("DuplicateTemp")]
        public string DuplicateTemp(string Brnch, string BrnchTo)
        {
            string result = "";
            try
            {
                result = DAL.dal_Snapshot.DuplicateTemplate(Brnch, BrnchTo);
                return result;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }

        [HttpDelete]
        [Route("DeleteTemp")]
        public string DeleteTemp(string Brnch)
        {

            string result = "";
            try
            {
                result = DAL.dal_Snapshot.RemoveTemplate( Brnch);
                return result;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }

        [HttpGet]
        [Route("CheckDuplicate")]
        public DataTable CheckDuplicate(string Brnch)
        {
            try
            {
                DataTable dt = DAL.dal_Snapshot.CheckDuplicate(Brnch);
                return dt;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
    }
}
