﻿using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Security.Claims;
using System.Threading;



namespace Snapshot_API.Controllers
{
    

        
  
    [RoutePrefix("api/users")]
    public class UsersController : ApiController
    {
        [HttpGet]
        [Route("myinfo")]
        public IHttpActionResult GetInfo()
        { 
            
            //Get the current claims principal
            var identity = (ClaimsPrincipal)Thread.CurrentPrincipal;
            // Get the claims values
            User model = new User();
            model.EmpID = identity.Claims.Where(c => c.Type == ClaimTypes.Sid)
                               .Select(c => c.Value).SingleOrDefault();
            model.EmpName = identity.Claims.Where(c => c.Type == ClaimTypes.Name)
                               .Select(c => c.Value).SingleOrDefault();
            model.FName = identity.Claims.Where(c => c.Type == ClaimTypes.GivenName)
                               .Select(c => c.Value).SingleOrDefault();
            model.UType = identity.Claims.Where(c => c.Type == ClaimTypes.Role)
                               .Select(c => c.Value).SingleOrDefault();
            model.Dept = identity.Claims.Where(x => x.Type == "Dept").Select(x => x.Value).SingleOrDefault();
            model.WhsCode = identity.Claims.Where(x => x.Type == "WhsCode").Select(x => x.Value).SingleOrDefault();
            model.DeptCode = Convert.ToInt32(identity.Claims.Where(x => x.Type == "DeptCode").Select(x => x.Value).SingleOrDefault());
            model.SecCode = Convert.ToInt32(identity.Claims.Where(x => x.Type == "SecCode").Select(x => x.Value).SingleOrDefault());
            return Ok(model);
        }
        [HttpGet]
        [Route("CheckAccessRights")]
        public IHttpActionResult Get(string userid)
        {
            try
            {
                DataTable dt = DAL.dal_Users.check(userid);
                return Ok(dt);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpGet]
        [Route("get")]
        public IHttpActionResult Get()
        {
            try
            {
                List<object> model = DAL.dal_Users.Get();
                return Ok(model);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [Route("UpdateUser")]
        [HttpPut]
        public string UpdateUser([FromBody]UpdateUser User)
        {
            string Results = "";
            try{
            
              Results=   DAL.dal_Users.Update(User);
              return Results;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [Route("AddUser")]
        [HttpPost]
        public string AddUser([FromBody]AddUser User)
        {
            string Results = "";
            try
            {

                Results = DAL.dal_Users.Add(User);
                return Results;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [Route("DeleteUser")]
        [HttpDelete]
        public string DeleteUser([FromUri]string UserID)
        {
            string Results = "";
            try
            {

                Results = DAL.dal_Users.Remove(UserID);
                return Results;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        
    }

}
