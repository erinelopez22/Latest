﻿using Snapshot_API.Helpers;
using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Snapshot_API.DAL
{
    public class dal_Auth
    {
        public static User Login(string username, string password)
        {
            SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
            var str = "EXEC HPCOMMON.dbo.UserLogin @user,@pass";
            DataTable dt = tool.sqlDT(str, new SqlParameter("@user", username), new SqlParameter("@pass", password));
            
            User model = new User();
            if (dt.Rows.Count > 0)
            {
                SQLTool tool2 = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                var str2 = "SELECT * FROM Bookkeeping.dbo.snap_Users WHERE EmpCode=@EmpID ";
                DataTable dt2 = tool2.sqlDT(str2, new SqlParameter("@EmpID", dt.Rows[0]["EmpID"]));
                if (dt2.Rows.Count > 0)
                {

                    model.EmpID = Convert.ToString(dt.Rows[0]["EmpID"]);
                    model.EmpName = Convert.ToString(dt.Rows[0]["EmpName"]);
                    model.FName = Convert.ToString(dt.Rows[0]["FName"]);
                    model.UType = Convert.ToString(dt2.Rows[0]["UType"]);
                    model.WhsCode = Convert.ToString(dt.Rows[0]["WhsCode"]);
                    model.Dept = Convert.ToString(dt.Rows[0]["Dept"]);
                    model.DeptCode = Convert.ToInt32(dt.Rows[0]["DeptCode"]);
                    model.SecCode = Convert.ToInt32(dt.Rows[0]["SecCode"]);
                    model.Role = Convert.ToString(dt2.Rows[0]["UType"]);
                    dt.Dispose();
                    tool.Dispose();
                }
                else
                {
                    tool.Dispose();
                    throw new ApplicationException("User not registered in Snapshot application.");
                }
            }
            else
            {
                tool.Dispose();
                throw new ApplicationException("User not found.");
            }

            return model;
        }
    }
}