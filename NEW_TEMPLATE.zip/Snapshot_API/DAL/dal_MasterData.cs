﻿using Snapshot_API.Helpers;
using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;


namespace Snapshot_API.DAL
{
    public class dal_MasterData
    {
        public static List<object> Employees()
        {
            SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
            var str = "SELECT EmpCode,EmpName FROM HPCOMMON.dbo.SCEmpNew WHERE DateResigned IS NULL OR DateResigned > GETDATE()";
            DataTable dt = tool.sqlDT(str);
            List<object> model = new List<object>();
            foreach (var item in dt.Select())
            {
                model.Add(new
                {
                    EmpCode = Convert.ToString(item["EmpCode"]),
                    EmpName = Convert.ToString(item["EmpName"])
                });
            }
            dt.Dispose();
            tool.Dispose();

            return model;
        }
        public static List<object> branches_()
        {
            SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
            var str = "select blk,code from HPCOMMON.dbo.SAPSet WHERE Stat='O'";
            DataTable dt = tool.sqlDT(str);
            List<object> model = new List<object>();
            foreach (var item in dt.Select())
            {
                model.Add(new
                {
                    BranchDscpt = Convert.ToString(item["blk"]),
                    BranchCode = Convert.ToString(item["code"])
                });
            }
            dt.Dispose();
            tool.Dispose();

            return model;
        }
    }
}