﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Snapshot_API.Helpers;
using Snapshot_API.Models;
using System.Data;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Excel = Microsoft.Office.Interop.Excel;
using System.Security.Claims;
using System.Threading;

namespace Snapshot_API.DAL
{
    public class dal_Snapshot
    {
        
        public static void readXLS(string Brnch, string FilePath)
        {
            FileInfo existingFile = new FileInfo(FilePath);
            using (ExcelPackage package = new ExcelPackage(existingFile))
            {
                //get the first worksheet in the workbook
                ExcelWorksheet worksheet = package.Workbook.Worksheets[3];
                int colCount = worksheet.Dimension.End.Column;  //get Column Count
                int rowCount = worksheet.Dimension.End.Row;     //get row count
                string data="";
                Object dataf = "";
                DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("RowCnt");
                for (int col = 1; col <= colCount; col++)
                {
                    dt.Columns.Add(col.ToString());
                }
                StringBuilder data2 = new StringBuilder();
                for (int row = 1; row <= rowCount; row++)
                {
                    dt.Rows.Add();
                    for (int col = 1; col <= colCount; col++)
                    {
                        if (col == 1) 
                        {
                            if (worksheet.Cells[row, col].Value == null) { data = ""; }
                            else { data = worksheet.Cells[row, col].Value.ToString(); }
                            dt.Rows[row - 1][col] = data;
                        }
                        else
                        {
                            if (worksheet.Cells[row, col].Value == null) { data = ""; }
                            else { data ="="+ worksheet.Cells[row, col].Formula.ToString(); }
                            dt.Rows[row - 1][col] = data;
                        }
                        
                    }
                    
                    dt.Rows[row - 1][0] = row;
                }
            }
        }
        public static void readXLSInterop(string Brnch, string FilePath)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook excelBook = excelApp.Workbooks.Open(FilePath);
            Excel.Worksheet excelSheet = excelBook.Sheets[3];
            Excel.Range excelRange = excelSheet.UsedRange;
            FileInfo existingFile = new FileInfo(FilePath);
             DataTable dt = new System.Data.DataTable();

            try
            {
                int rowCount = excelRange.Rows.Count;
                int colCount = excelRange.Columns.Count;
                int i = 0;

                string data = "";
                Object dataf = "";
               
                dt.Columns.Add("RowCnt");
                for (int col = 1; col <= colCount; col++)
                {
                    dt.Columns.Add(col.ToString());
                }
                StringBuilder data2 = new StringBuilder();
                for (int row = 1; row <= rowCount; row++)
                {
                    dt.Rows.Add();
                    for (int col = 1; col <= colCount; col++)
                    {
                        if (col == 1)
                        {
                            if (excelSheet.Cells[row, col].Value == null) { data = ""; }
                            else
                            {
                                

                                
                                data = excelSheet.Cells[row, col].Value.ToString() +"~" +
                                      excelSheet.Cells[row, col].Columns.Font.FontStyle + "~" +
                                      excelSheet.Cells[row, col].Columns.Font.Color + "~" +
                                      excelSheet.Cells[row, col].Columns.Font.Name + "~" +
                                      excelSheet.Cells[row, col].Columns.Interior.Color + "~";
                            }
                            dt.Rows[row - 1][col] = data;
                        }   
                        else
                        {
                            
                            if (excelSheet.Cells[row, col].Value == null) { data = ""; }
                            else {
                               
                                
                                data =  excelSheet.Cells[row, col].Formula.ToString()+"~"+
                                       excelSheet.Cells[row, col].Columns.Font.FontStyle + "~" +
                                      excelSheet.Cells[row, col].Columns.Font.Color + "~" +
                                      excelSheet.Cells[row, col].Columns.Font.Name + "~" +
                                      excelSheet.Cells[row, col].Columns.Interior.Color + "~";
                            
                            }
                            dt.Rows[row - 1][col] = data;
                        }

                    }

                    dt.Rows[row - 1][0] = row;
                }
                
            }
            catch (Exception Ex)
            { 
            }
            excelApp.Quit();
            readDT(dt, Brnch);
        }

        public static void createExcel()
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook excelBook = excelApp.Workbooks.Add(1);
            Excel.Worksheet excelSheet = (Excel.Worksheet)excelBook.Worksheets.get_Item(1);
            Excel.Range excelRange = excelSheet.UsedRange;
           
           

            try
            {


                excelSheet.Cells[1, 1] = "ID";
                excelSheet.Cells[1, 2] = "Name";
                excelSheet.Cells[2, 1] = "1";
                excelSheet.Cells[2, 2] = "One";
                excelSheet.Cells[3, 1] = "2";
                excelSheet.Cells[3, 2] = "Two";
                excelSheet.Cells[1, 1].Columns.Font.Color = "16711680";
                excelSheet.Cells[1, 1].Columns.Interior.Color = "10092543";
                excelSheet.Cells[1, 2].Columns.Font.Color = "16711680";
                excelSheet.Cells[1, 2].Columns.Interior.Color = "10092543";
                excelSheet.Cells[2, 1].Columns.Font.Color = "16711680";
                excelSheet.Cells[2, 1].Columns.Interior.Color = "10092543";


                excelBook.SaveAs("your-file-name.xls");
            }
            catch (Exception Ex)
            {
            }
            

        }
 
        public static void readDT(DataTable dt, string Brnch)
        {
           // dt.Columns.Add("RowCnt");
            try
            {
                int rowCnt=0;
                foreach (DataRow dr in dt.Rows) 
                {
                    if(rowCnt >= 6)
                    {
                       
                        if (dr[1].ToString().Trim() == "") { }
                        else
                        {
                            
                            Snapshot ssModel = new Snapshot();
                            if (dr[2].ToString().Trim() == "") {
                                ssModel.Formula = "";
                                ssModel.ColFC = "";
                                ssModel.TotalFC = "";
                                ssModel.ColBG = "";
                                ssModel.TotalBG = "";
                            }
                            else
                            {
                                string[] ValAttrb = dr[2].ToString().Split('~');
                                ssModel.Formula = ValAttrb[0].ToString();
                                ssModel.ColFC = ValAttrb[2].ToString();
                                ssModel.TotalFC = ValAttrb[2].ToString();
                                ssModel.ColBG = ValAttrb[4].ToString();
                                ssModel.TotalBG = ValAttrb[4].ToString();
                            }
                            string[] descpAttrb = dr[1].ToString().Split('~');
                           
                            ssModel.WhsCode = Brnch;
                            ssModel.Descrip = descpAttrb[0].ToString();
                            ssModel.RowNo = Convert.ToInt32(dr["RowCnt"]);
                            
                            ssModel.TotalFormula ="";
                            ssModel.FontStyle = descpAttrb[1].ToString();

                            ssModel.DescripFC = descpAttrb[2].ToString();
                            

                            ssModel.DescripBG = descpAttrb[4].ToString();

                            ssModel.ColTop = "";
                            ssModel.ColBot = "";

                            postSnapshotTemplate(ssModel);
                        }
                        
                    }
                    rowCnt += 1;
                }

            }
            catch (Exception Ex) 
            { }
            
        }
        public static string postSnapshotTemplate(Snapshot SnapDet)
        {
            try
            {
                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "";
                str = "exec Bookkeeping.dbo.sp_snapMain @mode, @WhsCode, @Descrip, @RowNo,@Formula, @TotalFormula, @FontStyle,@DescripFC, @ColFC, @TotalFC,@DescripBG, @ColBG, @TotalBG,@ColTop, @ColBot";
                tool.sqlExecute(str,
                                           new SqlParameter("@mode", "AddSnapTemp"),
                                           new SqlParameter("@WhsCode", SnapDet.WhsCode),
                                           new SqlParameter("@Descrip", SnapDet.Descrip),
                                           new SqlParameter("@RowNo", SnapDet.RowNo),
                                           new SqlParameter("@Formula", SnapDet.Formula),
                                           new SqlParameter("@TotalFormula", SnapDet.TotalFormula),
                                           new SqlParameter("@FontStyle", SnapDet.FontStyle),
                                           new SqlParameter("@DescripFC", SnapDet.DescripFC),
                                           new SqlParameter("@ColFC", SnapDet.ColFC),
                                           new SqlParameter("@TotalFC", SnapDet.TotalFC),
                                           new SqlParameter("@DescripBG", SnapDet.DescripBG),
                                           new SqlParameter("@ColBG", SnapDet.ColBG),
                                           new SqlParameter("@TotalBG", SnapDet.TotalBG),
                                           new SqlParameter("@ColTop", SnapDet.ColTop),
                                           new SqlParameter("@ColBot", SnapDet.ColBot)
                                           );
              
                tool.Dispose();
                return "Successfuly Inserted Data";


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                return ex.Message;
            }
        }
        public static string GetSSperBranch(string whcode)
        {
            try
            {
                string str = "";
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                str = "exec Bookkeeping.dbo.sp_snapMain @mode,'', '', 0,'', '', '','', '', '','', '', '','', ''";
                tool.sqlDT(str,
                           new SqlParameter("@mode", "AddSnapTemp"),
                           new SqlParameter("@WhsCode", whcode));
                tool.Dispose();
                return "success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                return ex.Message;
            }
        }
        public static DataTable GetSSAllBranch()
        {
            try
            {
                string str = "";
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                str = "exec Bookkeeping.dbo.sp_snapMain @mode,'', '', 0,'', '', '','', '', '','', '', '','', ''";
                DataTable dt = tool.sqlDT(str,
                                           new SqlParameter("@mode", "SelectAllBranch"));
                tool.Dispose();
                return dt;
            }
            catch (Exception ex){throw new ApplicationException(ex.Message);}
        }
        public static DataTable getDash(int Yr)
        {
            try
            {
                string str = "";
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                str = "exec Bookkeeping.dbo.sp_snapMain @mode,'', '', @RowNo ,'', '', '','', '', '','', '', '','', ''";
                DataTable dt = tool.sqlDT(str,
                                           new SqlParameter("@mode", "SelectDash"),
                                           new SqlParameter("@RowNo", Yr));
                tool.Dispose();
                DataTable dt2 = changeCOl(dt);
                return dt2;
            }
            catch (Exception ex) { throw new ApplicationException(ex.Message); }
        }
        public static DataTable getDash2(int Yr)
        {
            try
            {
                string str = "";
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                str = "exec Bookkeeping.dbo.sp_snapMain @mode,'', '', @RowNo ,'', '', '','', '', '','', '', '','', ''";
                DataTable dt = tool.sqlDT(str,
                                           new SqlParameter("@mode", "SelectDash2"),
                                           new SqlParameter("@RowNo", Yr));
                tool.Dispose();
                DataTable dt2 = changeCOl(dt);
                return dt2;
            }
            catch (Exception ex) { throw new ApplicationException(ex.Message); }
        }
        public static DataTable changeCOl(DataTable dtr)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("BRANCH");
            dt.Columns.Add("JAN"); dt.Columns.Add("FEB"); dt.Columns.Add("MAR"); dt.Columns.Add("APR");
            dt.Columns.Add("MAY"); dt.Columns.Add("JUN"); dt.Columns.Add("JUL"); dt.Columns.Add("AUG");
            dt.Columns.Add("SEP"); dt.Columns.Add("OCT"); dt.Columns.Add("NOV"); dt.Columns.Add("DEC");
            dt.Columns.Add("Type");
            int i=0;
            foreach(DataRow dr in dtr.Rows)
            {
                dt.Rows.Add();
                dt.Rows[i][0]=dr["Blk"];
                if (dr["1"].ToString() == "0") { dt.Rows[i][1] = " - "; } else { dt.Rows[i][1] = " Ok "; }
                if (dr["2"].ToString() == "0") { dt.Rows[i][2] = " - "; } else { dt.Rows[i][2] = " Ok "; }
                if (dr["3"].ToString() == "0") { dt.Rows[i][3] = " - "; } else { dt.Rows[i][3] = " Ok "; }
                if (dr["4"].ToString() == "0") { dt.Rows[i][4] = " - "; } else { dt.Rows[i][4] = " Ok "; }
                if (dr["5"].ToString() == "0") { dt.Rows[i][5] = " - "; } else { dt.Rows[i][5] = " Ok "; }
                if (dr["6"].ToString() == "0") { dt.Rows[i][6] = " - "; } else { dt.Rows[i][6] = " Ok "; }
                if (dr["7"].ToString() == "0") { dt.Rows[i][7] = " - "; } else { dt.Rows[i][7] = " Ok "; }
                if (dr["8"].ToString() == "0") { dt.Rows[i][8] = " - "; } else { dt.Rows[i][8] = " Ok "; }
                if (dr["9"].ToString() == "0") { dt.Rows[i][9] = " - "; } else { dt.Rows[i][9] = " Ok "; }
                if (dr["10"].ToString() == "0") { dt.Rows[i][10] = " - "; } else { dt.Rows[i][10] = " Ok "; }
                if (dr["11"].ToString() == "0") { dt.Rows[i][11] = " - "; } else { dt.Rows[i][11] = " Ok "; }
                if (dr["12"].ToString() == "0") { dt.Rows[i][12] = " - "; } else { dt.Rows[i][12] = " Ok "; }
                if (dr["Postedin"].ToString() == "SS") { dt.Rows[i][13] = "SS"; } else { dt.Rows[i][13] = "TB"; }
                i+=1;
            }
            return dt;
        }
        public static DataTable CheckDuplicate(string wc)
        
        {
            try
            {
                string str = "";
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                str = "exec Bookkeeping.dbo.sp_snapMain @mode,@WhsCode, '', 0,'', '', '','', '', '','', '', '','', ''";
                DataTable dt = tool.sqlDT(str,
                                           new SqlParameter("@mode", "SelectDulicate"),
                                           new SqlParameter("@WhsCode", wc));

                tool.Dispose();
                
                tool.Dispose();
                return dt;
            }
            catch (Exception ex) { throw new ApplicationException(ex.Message); }
        }
        public static string RemoveTemplate(string wc)
        {
            try
            {
                string str = "";
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                str = "exec Bookkeeping.dbo.sp_snapMain @mode,@WhsCode, '', 0,'', '', '','', '', '','', '', '','', ''";
                tool.sqlDT(str,
                           new SqlParameter("@mode", "DeleteTempates"),
                           new SqlParameter("@WhsCode", wc));
                tool.Dispose();
                return "success";
            }
            catch (Exception ex) { throw new ApplicationException(ex.Message); return ex.Message; }
        }
        public static string DuplicateTemplate(string wc, string wc2)
        {
            try
            {
                string str = "";
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                str = "exec Bookkeeping.dbo.sp_snapMain @mode,@WhsCode, '', 0,'', '', '','', '', '','', '', '','', '',@WhsCodeFrom ";
                tool.sqlDT(str,
                           new SqlParameter("@mode", "DuplicateTemplates"),
                           new SqlParameter("@WhsCode", wc2),
                            new SqlParameter("@WhsCodeFrom", wc));
                tool.Dispose();
                return "success";
            }
            catch (Exception ex) { throw new ApplicationException(ex.Message); return ex.Message; }
        }
       
        public static DataTable Get(int Yr, int Pd, string whcode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                string str = "exec Bookkeeping.dbo.sp_snapFS @Year, @pd, @WhsCode";
                DataTable dt = tool.sqlDT(str, 
                                            new SqlParameter("@Year", Yr), 
                                            new SqlParameter("@pd", Pd), 
                                            new SqlParameter("@WhsCode", whcode)
                                            );
                
                tool.Dispose();
                return dt;
                
               
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static List<object> GetHdr(int year, string whcd)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                var str = "SELECT t0.DocNum,t0.WhsCode,t0.Yr,t0.Pd,t0.Total, "+
                          "t0.DateCreated,t2.EmpName,t0.CreatedBy, t1.Blk "+
                          "FROM [Bookkeeping].[dbo].[SSFSH] t0 " +
                          "INNER JOIN HPCOMMON.dbo.SAPSet t1 ON t0.WhsCode=t1.Code "+
                          "INNER JOIN HPCOMMON.dbo.SCEmpNew t2 ON t0.CreatedBy=t2.EmpCode "+
                          "WHERE CAST(YEAR(t0.DateCreated)AS INT) = @DateCreated AND WhsCode=@WhsCode ";
                DataTable dt = tool.sqlDT(str, new SqlParameter("@WhsCode", whcd), new SqlParameter("@DateCreated", year));
                foreach (var item in dt.Select())
                {
                    model.Add(new
                    {
                        DocNum = Convert.ToString(item["DocNum"]),
                        WhsCode = Convert.ToInt32(item["WhsCode"]),
                        Yr = Convert.ToString(item["Yr"]),
                        Pd = Convert.ToInt32(item["Pd"]),
                        Total = Convert.ToInt32(item["Total"]),
                        DateCreated = Convert.ToDecimal(item["DateCreated"]),
                        EmpName = Convert.ToDecimal(item["EmpName"]),
                        CreatedBy = Convert.ToDecimal(item["CreatedBy"]),
                        Branch = Convert.ToDecimal(item["Blk"])
                    });
                }
                dt.Dispose();
                tool.Dispose();
                return model;


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable ExportData(int Fromyear, int pd1, int Toyear, int pd2, string whcd)
        {
            try
            {
                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);



                //var str = "SELECT t4.Dscpt,t4.BegFormula,t4.DscrptBG,  " + "t4.TBType,t4.EndFormula,t4.DscrptFS,t4.DscrptFC,t4.DscrptTop,t4.DscrptBot, t4.RowNo,t4.DocEntry,  " + "t0.WhsCode,t0.Yr,t0.Pd,t5.EndAmt AS Total,t0.DateCreated, t2.EmpName,t0.CreatedBy,t1.Blk  " +
                //"FROM [Bookkeeping].[dbo].[SSFSH] t0 LEFT JOIN Bookkeeping.dbo.snap_Templates t4 ON t0.WhsCode = t4.WhsCode  "+
                //"INNER JOIN HPCOMMON.dbo.SAPSet t1 ON t0.WhsCode = t1.Code  "+
                //"LEFT JOIN HPCOMMON.dbo.SCEmpNew t2 ON t0.CreatedBy = t2.EmpCode  "+
                //"LEFT JOIN [Bookkeeping].[dbo].SSFS1 t3 ON t0.DocNum = t3.DocNum AND t3.DocEntry=t4.DocEntry  "+
                //"LEFT JOIN Bookkeeping.dbo.BKFS t5 ON t4.DocEntry=t5.DocEntry AND t0.WhsCode=t5.WhsCode AND t0.Yr=t5.Yr AND  "+"t0.Pd=t5.pd  "+
                //"WHERE CONVERT(DATE,  CONVERT(NVARCHAR,t0.Pd) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,t0.yr))  "+
                //"BETWEEN CONVERT(DATE,  CONVERT(NVARCHAR,@pd1) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Fromyear)) " +
                //"AND CONVERT(DATE,  CONVERT(NVARCHAR,@pd2) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Toyear)) " +
                //"AND  t5.POST=0 AND t0.WhsCode=@WhsCode AND t4.Dscpt != ''  ORDER BY  t0.Yr ASC  ";
                var str = "SELECT t4.Dscpt,t4.BegFormula,t4.DscrptBG,  " + "t4.TBType,t4.EndFormula,t4.DscrptFS,t4.DscrptFC,t4.DscrptTop,t4.DscrptBot, t4.RowNo,t4.DocEntry,  " + "t0.WhsCode,t0.Yr,t0.Pd,t3.Amount AS Total,t0.DateCreated, t2.EmpName,t0.CreatedBy,t1.Blk  " +
              "FROM [Bookkeeping].[dbo].[SSFSH] t0 LEFT JOIN Bookkeeping.dbo.snap_Templates t4 ON t0.WhsCode = t4.WhsCode  " +
              "INNER JOIN HPCOMMON.dbo.SAPSet t1 ON t0.WhsCode = t1.Code  " +
              "LEFT JOIN HPCOMMON.dbo.SCEmpNew t2 ON t0.CreatedBy = t2.EmpCode  " +
              "LEFT JOIN [Bookkeeping].[dbo].SSFS1 t3 ON t0.DocNum = t3.DocNum AND t3.DocEntry=t4.DocEntry  " +
              "WHERE CONVERT(DATE,  CONVERT(NVARCHAR,t0.Pd) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,t0.yr))  " +
              "BETWEEN CONVERT(DATE,  CONVERT(NVARCHAR,@pd1) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Fromyear)) " +
              "AND CONVERT(DATE,  CONVERT(NVARCHAR,@pd2) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Toyear)) " +
              "AND t0.WhsCode=@WhsCode AND t4.Dscpt != ''  ORDER BY  t0.Yr ASC  ";
                DataTable dt = tool.sqlDT(str, new SqlParameter("@WhsCode", whcd), new SqlParameter("@Fromyear", Fromyear), new SqlParameter("@pd1", pd1), new SqlParameter("@Toyear", Toyear), new SqlParameter("@pd2", pd2));
                
                
               
                dt.Dispose();
                tool.Dispose();
                return dt;


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable ExportData2(int Fromyear, int pd1, int Toyear, int pd2, string whcd)
        {
            try
            {
                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);



                var str = "SELECT t4.Dscpt,t4.BegFormula,t4.DscrptBG,  " + "t4.TBType,t4.EndFormula,t4.DscrptFS,t4.DscrptFC,t4.DscrptTop,t4.DscrptBot, t4.RowNo,t4.DocEntry,  " + "t0.WhsCode,t0.Yr,t0.Pd,t5.EndAmt AS Total,t0.DateCreated, t2.EmpName,t0.CreatedBy,t1.Blk  " +
                "FROM [Bookkeeping].[dbo].[SSFSH] t0 LEFT JOIN Bookkeeping.dbo.snap_Templates t4 ON t0.WhsCode = t4.WhsCode  " +
                "INNER JOIN HPCOMMON.dbo.SAPSet t1 ON t0.WhsCode = t1.Code  " +
                "LEFT JOIN HPCOMMON.dbo.SCEmpNew t2 ON t0.CreatedBy = t2.EmpCode  " +
                "LEFT JOIN [Bookkeeping].[dbo].SSFS1 t3 ON t0.DocNum = t3.DocNum AND t3.DocEntry=t4.DocEntry  " +
                "LEFT JOIN Bookkeeping.dbo.BKFS t5 ON t4.DocEntry=t5.DocEntry AND t0.WhsCode=t5.WhsCode AND t0.Yr=t5.Yr AND  " + "t0.Pd=t5.pd  " +
                "WHERE CONVERT(DATE,  CONVERT(NVARCHAR,t0.Pd) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,t0.yr))  " +
                "BETWEEN CONVERT(DATE,  CONVERT(NVARCHAR,@pd1) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Fromyear)) " +
                "AND CONVERT(DATE,  CONVERT(NVARCHAR,@pd2) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Toyear)) " +
                "AND  t5.POST=0 AND t0.WhsCode=@WhsCode AND t4.Dscpt != '' ORDER BY  t0.Yr ASC  ";
                DataTable dt = tool.sqlDT(str, new SqlParameter("@WhsCode", whcd), new SqlParameter("@Fromyear", Fromyear), new SqlParameter("@pd1", pd1), new SqlParameter("@Toyear", Toyear), new SqlParameter("@pd2", pd2));



                dt.Dispose();
                tool.Dispose();
                return dt;


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable SS_DATAwithFormula(string whcd)
        {
            try
            {
                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);



                var str = "SELECT RowNo, DocEntry AS SS_DocEntry, Descrip, "+
                        "0 AS TotalAmount,WhsCode,'SS' Type,2018 AS Yr,1 AS Pd,Formula AS ColBot, DescripFC,DescripBG,ColFC,ColBG " +
                        "FROM Bookkeeping.dbo.SSTemplate " +
                        "WHERE ColBot=1 AND WhsCode=@WhsCode ";
                DataTable dt = tool.sqlDT(str, new SqlParameter("@WhsCode", whcd));



                dt.Dispose();
                tool.Dispose();
                return dt;


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable SS_DATA_(int Fromyear, int pd1, int Toyear, int pd2, string whcd)
        {
            try
            {
                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);



                var str = "(SELECT a.RowNo,  b.SS_DocEntry, "+
                        "A.Descrip, "+
                        "((SELECT  SUM(x.Amount) FROM Bookkeeping.dbo.SSFS1 x "+
                        "INNER JOIN Bookkeeping.dbo.SS_TAGGING y ON y.DocEntry=x.DocEntry "+
                        "INNER JOIN Bookkeeping.dbo.SSFSH z ON z.DocNum=x.DocNum AND z.WhsCode=y.WhsCode "+
                        "WHERE y.SS_DocEntry=b.SS_DocEntry AND y.WhsCode=@WhsCode AND z.Yr=d.yr AND z.pd=d.pd) " +
                        ") AS TotalAmount, "+
                        "b.WhsCode,b.Type,d.yr,d.pd, "+
                        "a.DescripFC,a.DescripBG,a.ColFC,a.ColBG " +
                        "FROM Bookkeeping.dbo.SSTEMPLATE a "+
                        "RIGHT JOIN Bookkeeping.dbo.SS_TAGGING B ON A.DocEntry=b.SS_DocEntry  AND b.WhsCode=@WhsCode " +
                        "RIGHT JOIN Bookkeeping.dbo.snap_Templates C ON b.DocEntry=c.DocEntry AND c.WhsCode=@WhsCode " +
                        "INNER JOIN Bookkeeping.dbo.SSFS1 e ON e.DocEntry=C.DocEntry "+
                        "INNER JOIN Bookkeeping.dbo.SSFSH d ON d.DocNum=e.DocNum  AND d.WhsCode=@WhsCode   " +
                        "WHERE B.WhsCode=@WhsCode  AND  CONVERT(DATE,  CONVERT(NVARCHAR,d.pd) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,d.yr)) " +
                        "BETWEEN CONVERT(DATE,  CONVERT(NVARCHAR,@pd1) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Fromyear)) " +
                        "AND CONVERT(DATE,  CONVERT(NVARCHAR,@pd2) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Toyear)) " +
                        "GROUP BY a.RowNo, b.SS_DocEntry,A.Descrip, b.WhsCode,b.Type,d.yr,d.pd,a.DescripFC,a.DescripBG,a.ColFC,a.ColBG) " +
                        "ORDER BY d.pd";
                DataTable dt = tool.sqlDT(str, new SqlParameter("@WhsCode", whcd), new SqlParameter("@Fromyear", Fromyear), new SqlParameter("@pd1", pd1), new SqlParameter("@Toyear", Toyear), new SqlParameter("@pd2", pd2));



                dt.Dispose();
                tool.Dispose();
                return dt;


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable SS_DATA(int Fromyear, int pd1, int Toyear, int pd2, string whcd)
        {
            try
            {
                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);



                var str = "(SELECT  b.SS_DocEntry AS Doc, " +
                        "A.Descrip, B.DocEntry,c.Dscpt, e.Amount,  "+
                        "((SELECT  SUM(x.Amount) FROM Bookkeeping.dbo.SSFS1 x "+
                        "INNER JOIN Bookkeeping.dbo.SS_TAGGING y ON y.DocEntry=x.DocEntry "+
                        "INNER JOIN Bookkeeping.dbo.SSFSH z ON z.DocNum=x.DocNum AND z.WhsCode=y.WhsCode "+
                        "WHERE y.SS_DocEntry=b.SS_DocEntry AND y.WhsCode=@WhsCode AND z.Yr=d.yr AND z.pd=d.pd) " +
                        ") AS TotalAmount, "+
                        "b.WhsCode,b.Type,d.yr,d.pd,a.ColBot "+
                        "FROM Bookkeeping.dbo.SSTEMPLATE a "+
                        "RIGHT JOIN Bookkeeping.dbo.SS_TAGGING B ON A.DocEntry=b.SS_DocEntry  AND b.WhsCode=@WhsCode " +
                        "RIGHT JOIN Bookkeeping.dbo.snap_Templates C ON b.DocEntry=c.DocEntry AND c.WhsCode=@WhsCode " +
                        "INNER JOIN Bookkeeping.dbo.SSFS1 e ON e.DocEntry=C.DocEntry "+
                        "INNER JOIN Bookkeeping.dbo.SSFSH d ON d.DocNum=e.DocNum  AND d.WhsCode=@WhsCode  " +
                        "WHERE B.WhsCode=@WhsCode  AND  CONVERT(DATE,  CONVERT(NVARCHAR,d.pd) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,d.yr)) " +
                        "BETWEEN CONVERT(DATE,  CONVERT(NVARCHAR,@pd1) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Fromyear)) " +
                        "AND CONVERT(DATE,  CONVERT(NVARCHAR,@pd2) +'/'+ '1'+ '/'+ CONVERT(NVARCHAR,@Toyear)) " +
                        "GROUP BY  b.SS_DocEntry,A.Descrip, B.DocEntry,c.Dscpt, e.Amount, b.WhsCode,b.Type,d.yr,d.pd,a.ColBot) "+
                        "ORDER BY d.pd ";
                DataTable dt = tool.sqlDT(str, new SqlParameter("@WhsCode", whcd), new SqlParameter("@Fromyear", Fromyear), new SqlParameter("@pd1", pd1), new SqlParameter("@Toyear", Toyear), new SqlParameter("@pd2", pd2));



                dt.Dispose();
                tool.Dispose();
                return dt;


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static List<object> GetDet(int docnum)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                List<object> model = new List<object>();
                var str = "SELECT t2.Dscpt, t0.DocNum,t0.DocEntry,t0.TBType,t0.Amount "+
                          "FROM Bookkeeping.dbo.SSFS1 t0 "+
                          "INNER JOIN Bookkeeping.dbo.SSFSH t1 ON t0.DocNum=t1.DocNum "+
                          "INNER JOIN Bookkeeping.dbo.snap_Templates t2 ON t1.WhsCode= t2.WhsCode "+
                          "AND t0.DocEntry=t2.DocEntry "+
                          "t0 WHERE DocNum=@DocNum ";
                DataTable dt = tool.sqlDT(str, new SqlParameter("@DocNum",docnum));
                foreach (var item in dt.Select())
                {
                    model.Add(new
                    {
                        DocNum = Convert.ToInt32(item["DocNum"]),
                        DocEntry = Convert.ToInt32(item["DocEntry"]),
                        TBType = Convert.ToString(item["TBType"]),
                        Amount = Convert.ToDecimal(item["Amount"]),
                        Dscpt = Convert.ToDecimal(item["Dscpt"])
                    });
                }
                dt.Dispose();
                tool.Dispose();
                return model;


            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public static string ForPost(ForPostingModel Rtp, string createdBy)
        {

            //ForHeader
            try
            {
                string dt_BalSht = BS_ForPostng(Rtp, Rtp.BalSht, createdBy);
            }
            catch (Exception Ex)
            {
                throw new ApplicationException(Ex.Message);
                return Ex.Message;
            }
            try
            {
                string dt_IncSht = IS_ForPostng(Rtp, Rtp.IncState, createdBy);
            }
            catch (Exception Ex)
            {
                throw new ApplicationException(Ex.Message);
                return Ex.Message;
            }


            return "Data Successfuly Posted";
        }
        public static DataTable checkPosted(string wc, int yr, int pd)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "SELECT * FROM Bookkeeping.dbo.SSFSH WHERE WhsCode=@ws AND yr=@yr AND pd=@pd";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@ws", wc),
                                            new SqlParameter("@yr", yr),
                                            new SqlParameter("@pd", pd)
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable GetRpt(string wc, int yr, int pd,string tbtype)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[spSnapLoad] @WhsCode, @Yr, @Pd,@TBType";
               DataTable dt= tool.sqlDT(str,
                                            new SqlParameter("@WhsCode", wc),
                                            new SqlParameter("@Yr", yr),
                                            new SqlParameter("@Pd", pd),
                                            new SqlParameter("@TBType", tbtype)
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        private static string BS_ForPostng(ForPostingModel Rtp, List<ForPostingModel_BS> Sht, string createdBy)
        {
            string result = "";
            
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("Blk");
            dt1.Columns.Add("Dscpt");
            dt1.Columns.Add("wc");
            dt1.Columns.Add("Yr");
            dt1.Columns.Add("Pd");
            dt1.Columns.Add("EndAmt");
            dt1.Columns.Add("DocDate");
            dt1.Columns.Add("DocEntry");
            dt1.Columns.Add("TBType");
            int cnt = 0;
            if (Sht == null) { return "No Data Found"; }
            else 
            { 
                foreach (var item in Sht)
                {
                    dt1.Rows.Add();
                    dt1.Rows[cnt][0] = item.Blk;
                    dt1.Rows[cnt][1] = item.Dscpt;
                    dt1.Rows[cnt][2] = item.wc;
                    dt1.Rows[cnt][3] = item.Yr;
                    dt1.Rows[cnt][4] = item.Pd;
                    dt1.Rows[cnt][5] = item.EndAmt;
                    dt1.Rows[cnt][6] = item.DocDate;
                    dt1.Rows[cnt][7] = item.DocEntry;
                    dt1.Rows[cnt][8] = item.TBType;
                    cnt += 1;
                }
                foreach (var period in Rtp.BalSht.Select(x => new { x.Pd, x.Yr }).Distinct())
                {
                    AddSSFSH FS_hdr = new AddSSFSH();
                    List<AddSSFS1> FS_det = new List<AddSSFS1>();
                    var results = dt1.Select(" Pd = " + period.Pd + " AND Yr = " + period.Yr + " ").AsEnumerable().Take(1).CopyToDataTable();
                        FS_hdr.WhsCode = Convert.ToString(results.Rows[0][2]);
                        FS_hdr.Yr = Convert.ToInt32(results.Rows[0][3]);
                        FS_hdr.Pd = Convert.ToInt32(results.Rows[0][4]);
                        FS_hdr.Total = Convert.ToDecimal(results.Rows[0][5]);
                        FS_hdr.DateCreated = DateTime.Now;
                        FS_hdr.CreatedBy = createdBy;
                        DataRow[] results2 = dt1.Select(" Pd = " + period.Pd + " AND Yr = " + period.Yr);
                        FS_det = (from DataRow dr2 in results2
                                  select new AddSSFS1()
                                  {
                                      DocNum = 0,
                                      DocEntry = Convert.ToInt32(dr2["DocEntry"]),
                                      TBType = Convert.ToString(dr2["TBType"]),
                                      Amount = Convert.ToDecimal(dr2["EndAmt"])
                                  }).ToList();
                        try
                        {
                            result = Post(FS_hdr, FS_det);
                        }
                        catch (Exception Ex)
                        {
                            throw new ApplicationException(Ex.Message);
                        }

                    }
                }
            return result;
        }
        private static string IS_ForPostng(ForPostingModel Rtp, List<ForPostingModel_IS> Sht, string createdBy)
        {
            string result = "";
            string g = "";
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("Blk");
            dt1.Columns.Add("Dscpt");
            dt1.Columns.Add("wc");
            dt1.Columns.Add("Yr");
            dt1.Columns.Add("Pd");
            dt1.Columns.Add("CurrAmt");
            dt1.Columns.Add("DocDate");
            dt1.Columns.Add("DocEntry");
            dt1.Columns.Add("TBType");
            if (Sht == null) { return "No Data Found"; }
            else
            {

                int cnt = 0;
                foreach (var item in Sht)
                {
                    dt1.Rows.Add();
                    dt1.Rows[cnt][0] = item.Blk;
                    dt1.Rows[cnt][1] = item.Dscpt;
                    dt1.Rows[cnt][2] = item.wc;
                    dt1.Rows[cnt][3] = item.Yr;
                    dt1.Rows[cnt][4] = item.Pd;
                    dt1.Rows[cnt][5] = item.CurrAmt;
                    dt1.Rows[cnt][6] = item.DocDate;
                    dt1.Rows[cnt][7] = item.DocEntry;
                    dt1.Rows[cnt][8] = item.TBType;
                    cnt += 1;
                }
                foreach (var period in Rtp.IncState.Select(x => new { x.Pd, x.Yr }).Distinct())
                {
                    AddSSFSH FS_hdr = new AddSSFSH();
                    List<AddSSFS1> FS_det = new List<AddSSFS1>();
                    var results = dt1.Select(" Pd = " + period.Pd + " AND Yr = " + period.Yr + " ").AsEnumerable().Take(1).CopyToDataTable();
                    FS_hdr.WhsCode = Convert.ToString(results.Rows[0][2]);
                    FS_hdr.Yr = Convert.ToInt32(results.Rows[0][3]);
                    FS_hdr.Pd = Convert.ToInt32(results.Rows[0][4]);
                    FS_hdr.Total = Convert.ToDecimal(results.Rows[0][5]);
                    FS_hdr.DateCreated = DateTime.Now;
                    FS_hdr.CreatedBy = createdBy;
                    DataRow[] results2 = dt1.Select(" Pd = " + period.Pd + " AND Yr = " + period.Yr);
                    FS_det = (from DataRow dr2 in results2
                              select new AddSSFS1()
                              {
                                  DocNum = 0,
                                  DocEntry = Convert.ToInt32(dr2["DocEntry"]),
                                  TBType = Convert.ToString(dr2["TBType"]),
                                  Amount = Convert.ToDecimal(dr2["CurrAmt"])
                              }).ToList();
                    try
                    {
                        result = Post(FS_hdr, FS_det);
                    }
                    catch (Exception Ex)
                    {
                        throw new ApplicationException(Ex.Message);
                    }
                }
            }
                  //  

                  //}
            //}
            return result;
        }

        public static void PostNew(ForPostingModel model)
        {
            SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
            try
            {
                tool.BeginTran();
                var str = "SELECT COUNT(1) FROM [Bookkeeping].[dbo].[SSFSH] WHERE [WhsCode] = @WhsCode AND [Yr] = @Yr AND [Pd] = @Pd";
                int result = Convert.ToInt32(tool.sqlScalar(str,
                            new SqlParameter("@WhsCode", model.header.WhsCode),
                            new SqlParameter("@Yr", model.header.Yr),
                            new SqlParameter("@Pd", model.header.Pd)
                        ));
                if (result > 0) throw new ApplicationException("Selected branch, month and year already exist.");

                //GET USER DETAILS
                var identity = (ClaimsPrincipal)Thread.CurrentPrincipal;
                string empcode = identity.Claims.Where(c => c.Type == ClaimTypes.Sid).Select(c => c.Value).SingleOrDefault();

                //INSERT HEADER
                str = "INSERT INTO Bookkeeping.dbo.SSFSH([WhsCode],[Yr],[Pd],[Total],[CreatedBy]) " +
                        "VALUES(@WhsCode,@Yr,@Pd,0,@CreatedBy)";
                tool.sqlExecute(str,
                        new SqlParameter("@WhsCode", model.header.WhsCode),
                        new SqlParameter("@Yr", model.header.Yr),
                        new SqlParameter("@Pd", model.header.Pd),
                        new SqlParameter("@CreatedBy", empcode)
                    );

                //GET GENERATED IDENTITY DOCNUM
                int docnum = Convert.ToInt32(tool.sqlScalar("SELECT @@IDENTITY"));

                //LOOP DETAIL
                str = "INSERT INTO Bookkeeping.dbo.SSFS1(DocNum,DocEntry,TBType,Amount) VALUES(@DocNum, @DocEntry, @TBType, @Amount);";
                foreach (var item in model.BalSht)
                {
                    tool.sqlExecute(str,
                            new SqlParameter("@DocNum", docnum),
                            new SqlParameter("@DocEntry", item.DocEntry),
                            new SqlParameter("@TBType", item.TBType),
                            new SqlParameter("@Amount", item.EndAmt)
                        );
                }

                foreach (var item in model.IncState)
                {
                    tool.sqlExecute(str,
                            new SqlParameter("@DocNum", docnum),
                            new SqlParameter("@DocEntry", item.DocEntry),
                            new SqlParameter("@TBType", item.TBType),
                            new SqlParameter("@Amount", item.CurrAmt)
                        );
                }

                tool.Commit();
                tool.Dispose();
            }
            catch (Exception ex)
            {
                tool.Rollback();
                tool.Dispose();
                throw new ApplicationException(ex.Message);
            }
        }

        public static string Post(AddSSFSH FS_hdr, List<AddSSFS1> FS_det)
        {
            string isSuccess = "";
            int result = 0;
            int DocNum = 0;
            try
            {
                DataTable dt = new DataTable();
                try { 
                    SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);

                    var str = "exec Bookkeeping.dbo.sp_snapAddFS 0,@mode, @WhsCode, @Yr,@Pd,0,'','',0,'',0 ";
                    dt = tool.sqlDT(str, 
                        new SqlParameter("@mode", "CheckData"), 
                        new SqlParameter("@WhsCode", FS_hdr.WhsCode), 
                        new SqlParameter("@Yr", FS_hdr.Yr), 
                        new SqlParameter("@Pd", FS_hdr.Pd)
                        );
                    tool.Dispose();
                    }
                catch(Exception Ex)
                {
                    isSuccess = "Error occured in Selecting Data in sp_snapAddFS || " + Ex.Message.ToString();
                    return isSuccess;
                }
                
                if (dt.Rows.Count > 0)
                {
                    if (FS_det[0].TBType == "BS") { return "WarehouseCode, Month and Year Already Exist"; }
                    else
                    {
                        isSuccess = InserDetails(FS_hdr, FS_det);
                        isSuccess = "Successfuly Added Header and details";
                        return isSuccess;
                    }
                }
                else{
                    try
                    {
                        var str1 = "exec Bookkeeping.dbo.sp_snapAddFS 0,@mode, @WhsCode, @Yr,@Pd,@Total,@DateCreated,@CreatedBy,0,'',0 ";
                        SQLTool tool2 = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                        result = tool2.sqlExecute(str1, 
                                                    new SqlParameter("@mode", "AddHeader"), 
                                                    new SqlParameter("@DocNum", FS_hdr.DocNum), 
                                                    new SqlParameter("@WhsCode", FS_hdr.WhsCode), 
                                                    new SqlParameter("@Yr", FS_hdr.Yr), 
                                                    new SqlParameter("@Pd", FS_hdr.Pd), 
                                                    new SqlParameter("@Total", FS_hdr.Total), 
                                                    new SqlParameter("@DateCreated", FS_hdr.DateCreated), 
                                                    new SqlParameter("@CreatedBy", FS_hdr.CreatedBy));
                                 tool2.Dispose();
                    }
                    catch (Exception Ex)
                    {
                        isSuccess ="Error occured in Inserting FS Header || " + Ex.Message.ToString();
                        return isSuccess;
                    }
                    isSuccess = InserDetails(FS_hdr, FS_det);

                    isSuccess = "Successfuly Added Header and details";
                    return isSuccess;
                }
            }
            catch (Exception ex)
            {
                isSuccess = ex.Message.ToString();
                return isSuccess;
            }
            return isSuccess;
        }
        private static string InserDetails(AddSSFSH FS_hdr, List<AddSSFS1> FS_det)
        {
            int DocNum = 0;
            string isSuccess = "";
            if (FS_det != null)
            {
                try
                {
                    DataTable dt2 = new DataTable();
                    try
                    {
                        SQLTool tool_ = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);

                        var str_ = "exec Bookkeeping.dbo.sp_snapAddFS 0,@mode, @WhsCode, @Yr,@Pd,0,'','',0,'',0 ";
                        dt2 = tool_.sqlDT(str_, new SqlParameter("@mode", "CheckData"), new SqlParameter("@WhsCode", FS_hdr.WhsCode), new SqlParameter("@Yr", FS_hdr.Yr), new SqlParameter("@Pd", FS_hdr.Pd));
                        tool_.Dispose();
                    }
                    catch (Exception Ex)
                    {
                        isSuccess = "Error occured in Selecting Data in sp_snapAddFS || " + Ex.Message.ToString();
                        return isSuccess;
                    }
                    DocNum = Convert.ToInt32(dt2.Rows[0]["DocNum"]);
                    foreach (var det in FS_det)
                    {
                        var str2 = "exec Bookkeeping.dbo.sp_snapAddFS @Amount,@mode, '', 0,0,0,'','',@DocEntry,@TBType,@DocNum";
                        SQLTool tool3 = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                        tool3.sqlExecute(str2,
                            new SqlParameter("@mode", "AddDetail"),
                            new SqlParameter("@DocNum", DocNum),
                            new SqlParameter("@DocEntry", det.DocEntry),
                            new SqlParameter("@TBType", det.TBType),
                            new SqlParameter("@Amount", det.Amount));
                        tool3.Dispose();
                    }
                }
                catch (Exception Ex)
                {
                    isSuccess = "Error occured in Inserting FS details || " + Ex.Message.ToString();
                    return isSuccess;
                }
                
            }
            return isSuccess;
        }

        
    }
}