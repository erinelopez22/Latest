﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Snapshot_API.Helpers;
using Snapshot_API.Models;
using System.Data;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Excel = Microsoft.Office.Interop.Excel;

namespace Snapshot_API.DAL
{
    public class dal_Tagging
    {

        public static DataTable GetRptDesc(string WhsCode,string type_)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_rpt_Tagging] @mode, @WhsCode, @DocEntry,@DocEntry2,@Type,@isTotal,@isHeader,'' ";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", type_),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@DocEntry2", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString(type_)),
                                            new SqlParameter("@isTotal", Convert.ToInt32(0)),
                                            new SqlParameter("@isHeader", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable GetRptTagged(string WhsCode, int docentry, string typ)
        {
            try
            {
                string sp = "";
                if (typ.Trim() == "SS") { sp = "SelectAllSSTagged"; } else { sp = "SelectAllTagged"; }
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_rpt_Tagging] @mode, @WhsCode, @DocEntry,@DocEntry2,@Type,@isTotal,@isHeader,'' ";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", sp),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(docentry)),
                                            new SqlParameter("@DocEntry2", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@isTotal", Convert.ToInt32(0)),
                                            new SqlParameter("@isHeader", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable GetDocEntry(string WhsCode, string Typ)
        {
            try
            {
                string sp = "";
                if (Typ.Trim() == "SS") { sp = "SSNew_DocEntry"; } else { sp = "New_DocEntry"; }
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_rpt_Tagging] @mode, @WhsCode, @DocEntry,@DocEntry2,@Type,@isTotal,@isHeader,'' ";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", sp),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@DocEntry2", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@isTotal", Convert.ToInt32(0)),
                                            new SqlParameter("@isHeader", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static string addRpt_Tagged(TaggingModel model)
        {
            string res = "";
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                if (model.Type_ == "SS") 
                {
                    string str = "exec Bookkeeping.dbo.[sp_rpt_Tagging] @mode, @WhsCode, @DocEntry,@DocEntry2,@Type,@isHeader,@isTotal,@operation";
                    tool.sqlExecute(str,
                                                new SqlParameter("@mode", "AddTaggedSS"),
                                                new SqlParameter("@WhsCode", model.WhsCode),
                                                new SqlParameter("@DocEntry", model.DOCENTRY),
                                                new SqlParameter("@DocEntry2", model.DocEntry2),
                                                new SqlParameter("@Type", model.Type_),
                                                new SqlParameter("@isHeader", model.isHdr),
                                                new SqlParameter("@isTotal", model.isTotal),
                                                new SqlParameter("@operation", model.Operation)
                                                );
                
                }
                else
                {
                    string str = "exec Bookkeeping.dbo.[sp_rpt_Tagging] @mode, @WhsCode, @DocEntry,@DocEntry2,@Type,@isHeader,@isTotal,@operation";
                    tool.sqlExecute(str,
                                                new SqlParameter("@mode", "AddTagged"),
                                                new SqlParameter("@WhsCode", model.WhsCode),
                                                new SqlParameter("@DocEntry", model.DOCENTRY),
                                                new SqlParameter("@DocEntry2", model.DocEntry2),
                                                new SqlParameter("@Type", model.Type_),
                                                new SqlParameter("@isHeader", model.isHdr),
                                                new SqlParameter("@isTotal", model.isTotal),
                                                new SqlParameter("@operation", model.Operation)
                                                );
                }


                tool.Dispose();
                res = "Success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return res;
        }
        public static DataTable checkrow(TaggingMode2 model)
        {
            string res = "";
            DataTable dt = new System.Data.DataTable();
            try
            {

                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "SELECT DocEntry, RowNo FROM Bookkeeping.dbo.snap_Templates "+
                             "WHERE WhsCode=@wc AND TBType=@Type AND RowNo=@Rowno";
                 dt =tool.sqlDT(str,new SqlParameter("@wc", model.WhsCode),
                                    new SqlParameter("@Rowno", model.Rowno),
                                    new SqlParameter("@Type", model.Type_)
                                    );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return dt;
        }
        public static DataTable getMaxRow(TaggingMode2 model)
        {
            string res = "";
            DataTable dt = new System.Data.DataTable();
            try
            {

                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "SELECT MAX(DocEntry) AS Row FROM Bookkeeping.dbo.snap_Templates " +
                             "WHERE WhsCode=@wc AND TBType=@Type";
                dt = tool.sqlDT(str, new SqlParameter("@wc", model.WhsCode),
                                   new SqlParameter("@Type", model.Type_)
                                   );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return dt;
        }
        public static void UpdateRows(TaggingMode2 model,int de)
        {
            string res = "";
            DataTable dt = new System.Data.DataTable();
            SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
            try
            {

                
                
                string str = "UPDATE Bookkeeping.dbo.snap_Templates SET RowNo=RowNo+1 " +
                             "WHERE WhsCode=@wc AND TBType=@Type AND DocEntry=@DocEntry";
                tool.sqlExecute(str, new SqlParameter("@wc", model.WhsCode),
                                   new SqlParameter("@DocEntry", de),
                                   new SqlParameter("@Type", model.Type_)
                                   );
                
                tool.Dispose();
               
            }
            catch (Exception ex)
            {
                
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
         
        }
        public static string addRpt_Row(TaggingMode2 model)
        {
            string res = "";
            try
            {

                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "INSERT INTO Bookkeeping.dbo.snap_Templates VALUES "+
                              "( @docentry, @desc, @wc, @Rowno, getdate(), @createdBy, @Type, '', '', '', " +
                              "'Regular', 'Regular', '&', '&', '@Color', '@Color', '-4142', '-4142', '-4142', '-4142', 0, NULL ) ";
                        tool.sqlExecute(str,
                                            new SqlParameter("@docentry",model.DocEntry),
                                            new SqlParameter("@desc", model.Desc),
                                            new SqlParameter("@wc", model.WhsCode),
                                            new SqlParameter("@Rowno", model.Rowno),
                                            new SqlParameter("@createdBy", model.createdBy),
                                            new SqlParameter("@Type", model.Type_),
                                            new SqlParameter("@Color", model.color)
                                            );


                tool.Dispose();
                res = "Success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return res;
        }
        public static string removeRpt_Tagged(TaggingModel model)
        {
            string res = "";
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                if (model.Type_ == "SS")
                {
                    string str = "exec Bookkeeping.dbo.[sp_rpt_Tagging] @mode, @WhsCode, @DocEntry,@DocEntry2,@Type,0,0,''";
                    tool.sqlExecute(str,
                                                new SqlParameter("@mode", "RemoveTaggedSS"),
                                                new SqlParameter("@WhsCode", model.WhsCode),
                                                new SqlParameter("@DocEntry", model.DOCENTRY),
                                                new SqlParameter("@DocEntry2", model.DocEntry2),
                                                new SqlParameter("@Type", model.Type_)
                                                );

                }
                else
                {
                    string str = "exec Bookkeeping.dbo.[sp_rpt_Tagging] @mode, @WhsCode, @DocEntry,@DocEntry2,@Type,0,0,''";
                    tool.sqlExecute(str,
                                                new SqlParameter("@mode", "RemoveTagged"),
                                                new SqlParameter("@WhsCode", model.WhsCode),
                                                new SqlParameter("@DocEntry", model.DOCENTRY),
                                                new SqlParameter("@DocEntry2", model.DocEntry2),
                                                new SqlParameter("@Type", model.Type_)
                                                );
                }

                
               


                tool.Dispose();
                res = "Success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return res;
        }

        public static DataTable getSSDesc(string WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str, 
                                            new SqlParameter("@mode", "SelectSS_Desc"),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;  
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable getAllTagged(int docEntry,string wc)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", "SelectAllTagged"),
                                            new SqlParameter("@WhsCode", wc),
                                            new SqlParameter("@DocEntry", null),
                                            new SqlParameter("@SS_DocEntry", docEntry),
                                            new SqlParameter("@Type", ""),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }


        public static DataTable getIS(string WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", Convert.ToString("IS_DESC")),
                                            new SqlParameter("@WhsCode", Convert.ToString(WhsCode)),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))

                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public static DataTable getSS(string WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", Convert.ToString("SS_DESC")),
                                            new SqlParameter("@WhsCode", Convert.ToString(WhsCode)),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable getBS(String WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry, @SS_DocEntry, @Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode",Convert.ToString("BS_DESC")),
                                            new SqlParameter("@WhsCode", Convert.ToString(WhsCode)),
                                            new SqlParameter("@DocEntry",Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable getTagged(string wc,int docEntry )
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry, @SS_DocEntry, @Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", Convert.ToString("getDesc")),
                                            new SqlParameter("@WhsCode", Convert.ToString(wc)),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(docEntry)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static string addTagged(string WhsCode, int DocEntry, int SS_DocEntry, string Type_,int hasformula)
        { 
            string res = "";
            try
            {
               
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                tool.sqlExecute(str,
                                            new SqlParameter("@mode", "AddTagged"),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", DocEntry),
                                            new SqlParameter("@SS_DocEntry", SS_DocEntry),
                                            new SqlParameter("@Type", Type_),
                                            new SqlParameter("@HasFormula", hasformula)
                                            );
                

                tool.Dispose();
                res = "Success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return res;
        }


        public static string removeTagged(string WhsCode, int DocEntry, int SS_DocEntry, string Type_)
        {
            string res = "";
            try
            {

                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                tool.sqlExecute(str,
                                            new SqlParameter("@mode", "RemoveTagged"),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", DocEntry),
                                            new SqlParameter("@SS_DocEntry", SS_DocEntry),
                                            new SqlParameter("@Type", Type_),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );
                tool.Dispose();
                res = "Success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return res;
        }
    }
}