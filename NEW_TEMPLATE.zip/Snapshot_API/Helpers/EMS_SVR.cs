﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_API.Helpers
{
    public class EMS_SVR
    {
        public static string Server = "192.171.10.51";
        public static string Database = "HPCOMMON";
        public static string DbUser = "sapdb";
        public static string DbPwd = "sapdb";
        public static int ProgId = 256;
    }
}