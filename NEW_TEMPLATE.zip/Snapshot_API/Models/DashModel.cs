﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace Snapshot_API.Models
{
    public class DashModel
    {
 
        public DataTable dash1 { get; set; }
        public DataTable dash2 { get; set; }


    
    }
}