﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_API.Models
{
    public class Snapshot
    {
        public int DocEntry { get; set; }
        public string WhsCode { get; set; }
        public string Descrip { get; set; }
        public int RowNo { get; set; }
        public string Formula { get; set; }
        public string TotalFormula { get; set; }
        public string FontStyle { get; set; }
        public string DescripFC { get; set; }
        public string ColFC { get; set; }
        public string TotalFC { get; set; }
        public string DescripBG { get; set; }
        public string ColBG { get; set; }
        public string TotalBG { get; set; }
        public string ColTop { get; set; }
        public string ColBot { get; set; }
    }
}