﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_API.Models
{
    public class TaggingModel
    {
        public string WhsCode { get; set; }
        public int DOCENTRY { get; set; }
        public int DocEntry2 { get; set; }
        public string Type_ { get; set; }
        public int isHdr { get; set; }
        public int isTotal { get; set; }

        public string Operation { get; set; }

    }
    public class TaggingMode2
    {
        
        public int DocEntry { get; set; }

        public string Desc { get; set; }
        public Int32 Rowno { get; set; }
        public string WhsCode { get; set; }
        public string createdBy { get; set; }
        public string Type_ { get; set; }
        public string color { get; set; }


    }
}