﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_API.Models
{
    public class UpdateUser
    {
        public string EmpCode { get; set; }
        public string UType { get; set; }

        public string ApprovedBy { get; set; }
    }
}